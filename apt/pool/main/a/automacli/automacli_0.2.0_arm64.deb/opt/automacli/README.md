# automacli

<p align="center">
  <img src="automacli-banner.svg" alt="automacli banner">
</p>

**Várias branches do mesmo repositório rodando lado a lado, cada uma com sua stack Docker isolada.**

[![CI](https://github.com/Gustavo210/automacli/actions/workflows/ci.yml/badge.svg)](https://github.com/Gustavo210/automacli/actions/workflows/ci.yml)
[![oclif](https://img.shields.io/badge/cli-oclif-brightgreen.svg)](https://oclif.io)

## Visão geral

O `automacli` deixa você trabalhar em várias branches do mesmo repositório ao mesmo tempo. Cada branch vira uma **task** com diretório, slot e portas próprios, e a stack Docker de cada uma sobe lado a lado sem conflito. Bancos, caches e outros serviços com estado rodam uma vez só, a partir do **repo base**, e são compartilhados.

Nada é específico de um repositório: o que muda de projeto para projeto fica em um **perfil** YAML controlado por você, e o que não for declarado é descoberto nos arquivos compose. O repo base se mantém atualizado sozinho e pode pré-aquecer caches (bundlers, compilação incremental) que as tasks herdam ao nascer.

Ele também traz utilitários de dia a dia: limpeza de diretórios, pacotes npm desatualizados, isolamento de recursos por slot e um servidor de monitoramento das tasks (HTTP e MCP).

## Documentação

A documentação completa fica em [`docs/`](docs/index.md), escrita em Markdown e publicada como site (VitePress) na Vercel.

| Página | Conteúdo |
|---|---|
| [Instalação](docs/instalacao.md) | Instalar, configurar o token, criar o primeiro perfil |
| [Requisitos e ambiente](docs/requisitos.md) | O que é obrigatório, o que é opcional e as estratégias de clone |
| [Como funciona](docs/como-funciona.md) | Tasks, slots, repo base e serviços compartilhados |
| [Perfil](docs/perfil.md) | Referência de todos os campos do perfil YAML |
| [Comandos](docs/comandos.md) | Referência de todos os comandos e flags |
| [Monitor](docs/monitor.md) | Servidor HTTP/MCP, API e recarregamento da configuração |
| [Isolamento de recursos](docs/isolamento.md) | Slices systemd, limites por slot e systemd-oomd |
| [Exemplos](docs/exemplos.md) | Perfis prontos para cenários comuns |
| [Releases](docs/releases.md) | Como uma versão é publicada (tarballs, .deb, .rpm, PKGBUILD) |
| [Solução de problemas](docs/solucao-de-problemas.md) | Erros conhecidos e o que fazer |

## Instalação

Sem depender de Node na máquina, a partir do último release:

```sh
curl -fsSL https://github.com/Gustavo210/automacli-releases/releases/latest/download/install.sh | bash
```

Há também pacotes `.deb`, `.rpm` e `PKGBUILD` em cada release. A partir do código:

```sh
git clone https://github.com/Gustavo210/automacli.git
cd automacli
pnpm install && pnpm build
pnpm link --global
```

## Primeiros passos

```sh
automacli doctor                                   # o que a máquina oferece
automacli init                                     # configura a máquina e cria o perfil a partir dos arquivos compose
automacli profile                                  # confere o perfil e as portas de cada slot
automacli clone minha-feature -f organizacao/repo  # cria a task e sobe a stack dela
automacli branches                                 # acompanha as tasks (TUI)
```

Cada comando aceita `--help`. A lista completa está em [Comandos](docs/comandos.md).

## Desenvolvimento

```sh
pnpm install
pnpm build        # compila para dist/
pnpm test         # mocha + eslint
bin/dev.js clone --help   # roda a partir do TypeScript, sem compilar
```

Os testes ficam em `test/`, espelhando a estrutura de `src/`, e rodam em CI a cada push e pull request. A documentação em `docs/` é a referência dos comandos e do perfil: ao mudar um comando, atualize `docs/comandos.md`.

## Contribuição

Contribuições são bem-vindas. Para ideias, melhorias ou correções, abra uma issue ou um pull request.

## Licença

[MIT](LICENSE).
